"""
evaluation.py
=============
Measures how good each trained model is by testing it on the TEST data.

Classification metrics: Accuracy, Precision, Recall, F1 Score, ROC AUC
Regression metrics:     MSE, RMSE, MAE, R2 Score
"""

import numpy as np
import pandas as pd
from sklearn.metrics import (
    accuracy_score, auc, classification_report, f1_score, mean_absolute_error,
    mean_squared_error, precision_score, r2_score, recall_score, roc_curve,
)
from sklearn.preprocessing import label_binarize

from preprocessing import CLASSIFICATION


# ----------------------------------------------------------------------
# ROC curve data
# ----------------------------------------------------------------------
def compute_roc(y_test, y_proba, n_classes):
    """
    Calculate the points of the ROC curve and the area under it (AUC).

    - 2 classes   : a normal ROC curve
    - 3+ classes  : a "micro-average" ROC curve (all classes combined)
    Returns None if it cannot be calculated (e.g. the test set has only one class).
    """
    if len(np.unique(y_test)) < 2:
        return None
    try:
        if n_classes == 2:
            fpr, tpr, _ = roc_curve(y_test, y_proba[:, 1])
        else:
            y_binary = label_binarize(y_test, classes=list(range(n_classes)))
            fpr, tpr, _ = roc_curve(y_binary.ravel(), y_proba.ravel())
        return {"fpr": fpr, "tpr": tpr, "auc": auc(fpr, tpr)}
    except ValueError:
        return None


# ----------------------------------------------------------------------
# Evaluate ONE model
# ----------------------------------------------------------------------
def evaluate_classification(model, X_test, y_test, n_classes):
    """Return (metrics dictionary, details dictionary) for a classifier."""
    y_pred = model.predict(X_test)

    # For 2 classes use "binary" scoring; for more classes average over the classes
    average = "binary" if n_classes == 2 else "weighted"

    metrics = {
        "Accuracy": accuracy_score(y_test, y_pred),
        "Precision": precision_score(y_test, y_pred, average=average, zero_division=0),
        "Recall": recall_score(y_test, y_pred, average=average, zero_division=0),
        "F1 Score": f1_score(y_test, y_pred, average=average, zero_division=0),
    }

    roc = compute_roc(y_test, model.predict_proba(X_test), n_classes)
    metrics["ROC AUC"] = roc["auc"] if roc else np.nan

    return metrics, {"y_pred": y_pred, "roc": roc}


def evaluate_regression(model, X_test, y_test):
    """Return (metrics dictionary, details dictionary) for a regressor."""
    y_pred = model.predict(X_test)
    mse = mean_squared_error(y_test, y_pred)

    metrics = {
        "MSE": mse,
        "RMSE": np.sqrt(mse),
        "MAE": mean_absolute_error(y_test, y_pred),
        "R2 Score": r2_score(y_test, y_pred),
    }
    return metrics, {"y_pred": y_pred}


# ----------------------------------------------------------------------
# Evaluate ALL models
# ----------------------------------------------------------------------
def evaluate_models(trained_models, X_test, y_test, problem_type, n_classes=None):
    """
    Evaluate every trained model.

    Returns:
        results_df - a table with one row per model
        details    - {"model name": {"y_pred": ..., "roc": ...}} used for the charts
    """
    rows = {}
    details = {}
    for name, model in trained_models.items():
        if problem_type == CLASSIFICATION:
            metrics, extra = evaluate_classification(model, X_test, y_test, n_classes)
        else:
            metrics, extra = evaluate_regression(model, X_test, y_test)
        rows[name] = metrics
        details[name] = extra

    results_df = pd.DataFrame(rows).T
    results_df.index.name = "Model"
    return results_df, details


def get_best_model(results_df, problem_type):
    """Return (model name, metric name, score) of the best model."""
    if problem_type == CLASSIFICATION:
        metric = "Accuracy"          # higher is better
    else:
        metric = "R2 Score"          # higher is better
    best_name = results_df[metric].idxmax()
    return best_name, metric, float(results_df.loc[best_name, metric])


def get_classification_report(y_test, y_pred, class_names):
    """Return a text report with precision / recall / F1 for every class."""
    return classification_report(
        y_test, y_pred, labels=list(range(len(class_names))),
        target_names=class_names, zero_division=0,
    )
