# 📈 Predictive Modeling Using Machine Learning

A beginner-friendly machine learning project with a clean **Streamlit dashboard**.
Upload any CSV dataset, train several algorithms, compare their performance, view the
charts, and make your own predictions.

---

## Table of Contents
1. [Project Objective](#1-project-objective)
2. [Features](#2-features)
3. [Technologies Used](#3-technologies-used)
4. [Project Structure](#4-project-structure)
5. [Installation (Step by Step)](#5-installation-step-by-step)
6. [How to Run](#6-how-to-run)
7. [Datasets](#7-datasets)
8. [Using the Dashboard](#8-using-the-dashboard)
9. [Sample Input and Output](#9-sample-input-and-output)
10. [Expected Output (Charts)](#10-expected-output-charts)
11. [How Each Algorithm Works](#11-how-each-algorithm-works)
12. [Understanding the Evaluation Metrics](#12-understanding-the-evaluation-metrics)
13. [How the Code Works (File by File)](#13-how-the-code-works-file-by-file)
14. [Project Demonstration Guide](#14-project-demonstration-guide)
15. [Uploading to GitHub](#15-uploading-to-github)
16. [Troubleshooting](#16-troubleshooting)
17. [Limitations and Future Improvements](#17-limitations-and-future-improvements)

---

## 1. Project Objective

Build a machine learning application that **predicts outcomes from a dataset**. The
application trains different algorithms, tests them on data they have never seen,
compares their accuracy, and visualises the results.

There are two kinds of prediction problems:

| Type | What is predicted | Example |
|---|---|---|
| **Classification** | A category / label | Will a student *Pass* or *Fail*? |
| **Regression** | A number | What is the *price* of a house? |

The app detects which type your dataset needs and offers the matching algorithms.

## 2. Features

| # | Feature | Where |
|---|---|---|
| 1 | Upload your own CSV (or use a built-in sample) | Sidebar |
| 2 | Automatic preprocessing: missing values, text → numbers, scaling | `preprocessing.py` |
| 3 | Train the algorithms you select | `models.py` |
| 4 | Train/test split (10–40 % test data, adjustable) | `preprocessing.py` |
| 5 | Model comparison table and charts | **Results** tab |
| 6 | Metrics: Accuracy, Precision, Recall, F1, ROC AUC, MSE, RMSE, MAE, R² | `evaluation.py` |
| 7 | Confusion matrix, ROC curve, Actual-vs-Predicted, comparison charts | `visualization.py` |
| 8 | Prediction form: type new values, get a prediction | **Predict** tab |

## 3. Technologies Used

- **Python 3.9+**
- **NumPy** – numerical calculations
- **Pandas** – reading and handling tables of data
- **Scikit-learn** – the machine learning algorithms and metrics
- **Matplotlib** and **Seaborn** – charts
- **Streamlit** – the web dashboard

## 4. Project Structure

```
predictive-modeling-ml/
│
├── app.py                    # Streamlit dashboard  (RUN THIS FILE)
├── preprocessing.py          # Load, clean, encode, split and scale data
├── models.py                 # Creates and trains the 6 algorithms
├── evaluation.py             # Calculates all performance metrics
├── visualization.py          # All charts (confusion matrix, ROC, etc.)
├── requirements.txt          # Libraries to install
├── README.md                 # This file
│
├── demo.py                   # Terminal version (no Streamlit needed) - handy for testing
├── generate_sample_data.py   # Re-creates the sample datasets
├── .gitignore                # Files Git should ignore
│
├── sample_data/
│   ├── student_performance.csv   # Classification: Pass / Fail   (300 rows, has missing values)
│   ├── house_prices.csv          # Regression: price in lakhs      (400 rows, has missing values)
│   └── iris.csv                  # Multi-class classification      (150 rows)
│
└── screenshots/              # Example charts created by demo.py
```

## 5. Installation (Step by Step)

### Step 1 – Install Python
Download Python 3.9 or newer from <https://www.python.org/downloads/>.
On Windows, tick **"Add Python to PATH"** during installation.
Check it worked:
```bash
python --version
```
(On macOS/Linux you may need to type `python3` instead of `python`.)

### Step 2 – Get the project
Download/unzip the project folder, then open a terminal inside it:
```bash
cd predictive-modeling-ml
```

### Step 3 – Create a virtual environment (recommended)
A virtual environment keeps this project's libraries separate from the rest of your computer.

**Windows**
```bash
python -m venv venv
venv\Scripts\activate
```
**macOS / Linux**
```bash
python3 -m venv venv
source venv/bin/activate
```
You should now see `(venv)` at the start of your terminal line.

### Step 4 – Install the libraries
```bash
pip install -r requirements.txt
```

## 6. How to Run

### Run the dashboard
```bash
streamlit run app.py
```
Your browser opens automatically at **http://localhost:8501**.
(If it does not, copy that address into your browser.) Press `Ctrl + C` in the terminal to stop the app.

### Run the terminal demo (optional)
```bash
python demo.py
```
This trains all models on the three sample datasets, prints the results, and saves charts
into `screenshots/`. It is a quick way to check that everything is installed correctly.

## 7. Datasets

### Included sample datasets
| File | Type | Target column | Notes |
|---|---|---|---|
| `student_performance.csv` | Classification | `result` (Pass/Fail) | Made-up data; contains missing values and text columns |
| `house_prices.csv` | Regression | `price_lakhs` | Made-up data; contains missing values and text columns |
| `iris.csv` | Multi-class classification | `species` | Real, famous dataset (3 flower types) |

The two made-up datasets are created by `generate_sample_data.py` (run `python generate_sample_data.py` to recreate them).

### Using your own dataset
Your CSV file should:
- have a **header row** (column names in the first row);
- have one column you want to predict (the **target**);
- have at least ~20 rows (more is better — hundreds is ideal).

Remove or ignore **ID columns** (use the *"Columns to ignore"* option in the sidebar).

### Where to get more datasets
- **Kaggle** – <https://www.kaggle.com/datasets> (search for *Titanic*, *Heart Disease*, *Diabetes*, *Telco Customer Churn*, *Student Performance*, *House Prices*)
- **UCI Machine Learning Repository** – <https://archive.ics.uci.edu/>
- **Built into scikit-learn** (no internet needed). Run this once to create ready-made CSV files:

```python
from sklearn.datasets import load_breast_cancer, load_diabetes

# Classification dataset - target column is called "target" (0 = malignant, 1 = benign)
load_breast_cancer(as_frame=True).frame.to_csv("breast_cancer.csv", index=False)

# Regression dataset - target column is called "target" (disease progression score)
load_diabetes(as_frame=True).frame.to_csv("diabetes.csv", index=False)
```

## 8. Using the Dashboard

The **sidebar** (left) is the control panel. The main area has three tabs.

1. **Choose a data source** – "Sample dataset" or "Upload my own CSV".
2. **Select the target column** – the column you want to predict.
3. *(Optional)* **Ignore columns** such as IDs, and set the **test data size**.
4. **Problem type** – leave on *Auto-detect* (the app shows what it detected).
5. **Select algorithms** – tick the models you want to train.
6. Click **🚀 Train Models**.
7. Explore the tabs:
   - **📊 Dataset** – preview, missing values, statistics, target distribution, correlation heatmap.
   - **🏆 Results** – best model, metrics table, comparison charts, confusion matrices, ROC curves (classification) or Actual-vs-Predicted graphs (regression), feature importance.
   - **🔮 Predict** – enter values, choose a model, press **Predict**.

> **Auto-detect rule:** a text target, or a whole-number target with 10 or fewer different
> values, is treated as *Classification*. Anything else is *Regression*. You can always override it.

## 9. Sample Input and Output

All numbers below come from running this project with the default settings
(20 % test data, `random_state=42`), so you should get the same results.

### Example A – Classification (`student_performance.csv`, target = `result`)

**Preprocessing report**
```
- Filled 51 missing values (median for numbers, most common value for text).
- One-hot encoded text columns: internet_access, extra_classes, parent_education.
- Target classes: Fail, Pass.
Training rows: 240   Testing rows: 60
```

**Model performance**
```
                          Accuracy  Precision  Recall  F1 Score  ROC AUC
Logistic Regression         0.7833     0.7872   0.925    0.8506   0.7925
Decision Tree Classifier    0.7000     0.7500   0.825    0.7857   0.6388
Random Forest Classifier    0.7833     0.8000   0.900    0.8471   0.7912

Best model: Logistic Regression (Accuracy = 0.783)
```

**Prediction – sample input**

| Column | Value |
|---|---|
| study_hours_per_day | 6.0 |
| attendance_percent | 85 |
| previous_exam_score | 70 |
| sleep_hours | 7.5 |
| internet_access | Yes |
| extra_classes | Yes |
| parent_education | Graduate |

**Output:** `Predicted result: Pass` – Logistic Regression gives **Pass 95.9 %** / Fail 4.1 %.
(All three models agree: *Pass*.)

A weaker profile (study 1 h/day, attendance 55 %, previous score 40, sleep 5 h, no internet,
no extra classes, High School) gives **Fail** with 97.1 % confidence.

### Example B – Regression (`house_prices.csv`, target = `price_lakhs`)

```
                              MSE     RMSE      MAE  R2 Score
Linear Regression        224.6215  14.9874  10.5244    0.9045
Decision Tree Regressor  438.0690  20.9301  15.0749    0.8137
Random Forest Regressor  295.8102  17.1991  11.8386    0.8742

Best model: Linear Regression (R2 Score = 0.904)
```

**Sample input:** area 1800 sq ft, 3 bedrooms, 2 bathrooms, 5 years old, Urban, with parking.

| Model | Predicted price (lakhs) |
|---|---|
| Linear Regression | 128.38 |
| Decision Tree Regressor | 111.99 |
| Random Forest Regressor | 121.73 |

> Linear Regression wins here because this sample data was created with a mostly straight-line
> relationship. On real-world data with complicated patterns, Random Forest often wins.

### Example C – Multi-class (`iris.csv`, target = `species`)
All three models reach **93.3 % accuracy**. Input `5.9, 3.0, 5.1, 1.8` (sepal length/width,
petal length/width in cm) → **virginica**.

## 10. Expected Output (Charts)

These charts were produced by this project's own code (`python demo.py`).

**Dashboard layout (what you will see)**
- A blue-to-teal banner with the project title and description.
- **Left sidebar:** data source, upload box, target selector, test-size slider, algorithm checklist and the **Train Models** button.
- **📊 Dataset tab:** four metric cards (rows, columns, missing values, duplicates), a table preview, a target-distribution chart and a correlation heatmap.
- **🏆 Results tab:** three metric cards (best model, best score, models trained), the metrics table, comparison charts, then confusion matrices side by side.
- **🔮 Predict tab:** a form with one input per column, a **Predict** button, the answer, and a bar chart of class probabilities.

### Classification
| Model comparison | ROC curves |
|---|---|
| ![Classification comparison](screenshots/classification_model_comparison.png) | ![ROC curves](screenshots/classification_roc_curves.png) |

| Confusion matrix | Multi-class (Iris) ROC curves |
|---|---|
| ![Confusion matrix](screenshots/classification_confusion_matrix.png) | ![Iris ROC](screenshots/multiclass_iris_roc_curves.png) |

### Regression
| Model comparison | Actual vs Predicted |
|---|---|
| ![Regression comparison](screenshots/regression_model_comparison.png) | ![Actual vs predicted](screenshots/regression_actual_vs_predicted.png) |

## 11. How Each Algorithm Works

### Regression models (predict a number)

**1. Linear Regression**
Finds the best straight line (or flat plane, when there are many columns) through the data.
The prediction is a weighted sum: `price = w1·area + w2·bedrooms + … + b`.
Training means finding the weights that make the total squared error as small as possible.
✅ Fast, easy to explain. ❌ Cannot capture curved or complicated relationships.

**2. Decision Tree Regressor**
Works like a game of *20 questions*. The tree asks yes/no questions about the columns
("Is area > 1500?") and splits the data into smaller and smaller groups. Each final group
(a "leaf") predicts the **average** value of the training rows inside it.
✅ Easy to visualise; handles curves. ❌ A deep tree memorises (overfits) the training data —
here we limit it with `max_depth=5`.

**3. Random Forest Regressor**
Builds **many** decision trees (100 here). Each tree is trained on a random sample of the rows
and sees random subsets of the columns, so every tree is a little different.
The forest's prediction is the **average of all the trees**. Averaging cancels out individual mistakes.
✅ Usually more accurate and stable than one tree. ❌ Slower, harder to explain.

### Classification models (predict a category)

**4. Logistic Regression**
Despite its name, it is a *classification* algorithm. It calculates a weighted sum of the columns
(like linear regression), then squeezes it through the **sigmoid function** to get a probability between 0 and 1.
If the probability is above 0.5 → one class, otherwise → the other. (With 3+ classes it uses the multinomial
version, giving one probability per class.)
✅ Fast, gives probabilities. ❌ Draws a straight boundary between classes.

**5. Decision Tree Classifier**
Same question-asking idea as the regression tree, but each leaf predicts the **most common class**
among its training rows. The questions are chosen to make each group as "pure" as possible (using Gini impurity).

**6. Random Forest Classifier**
Many decision-tree classifiers each cast a **vote**; the class with the most votes wins.
The share of votes also gives the probability for each class.

### Preprocessing in plain words
| Step | Why |
|---|---|
| **Fill missing values** | Models cannot handle blanks. Numbers → median, text → most common value. |
| **One-hot encoding** | Turns text like `Urban/Rural` into 1/0 columns, because models only understand numbers. |
| **Label encoding of the target** | Turns `Pass/Fail` into `1/0`. |
| **Train/test split** | The model learns from the training part; we judge it on the unseen test part. This shows how it would do on *new* data. |
| **Scaling** | Puts all numbers on a similar scale (mean 0), which helps Linear and Logistic Regression. The scaler learns from training data only. |

## 12. Understanding the Evaluation Metrics

### Classification
|  | Predicted: Fail | Predicted: Pass |
|---|---|---|
| **Actual: Fail** | True Negative (TN) | False Positive (FP) |
| **Actual: Pass** | False Negative (FN) | True Positive (TP) |

That table is the **confusion matrix**. The diagonal (TN, TP) holds the correct predictions.

| Metric | Formula | Meaning |
|---|---|---|
| **Accuracy** | (TP + TN) / all | Share of all predictions that were correct |
| **Precision** | TP / (TP + FP) | When the model says "Pass", how often is it right? |
| **Recall** | TP / (TP + FN) | Of all students who really passed, how many did the model find? |
| **F1 Score** | 2·P·R / (P + R) | One number that balances precision and recall |
| **ROC curve** | TPR vs FPR | Shows the trade-off as the decision threshold changes |
| **AUC** | area under ROC | 1.0 = perfect, 0.5 = random guessing |

For 3+ classes, Precision/Recall/F1 are averaged across classes (weighted by class size),
and the ROC curve is the *micro-average* of all classes.

### Regression
| Metric | Meaning |
|---|---|
| **MSE** (Mean Squared Error) | Average of (actual − predicted)². Lower is better. Big mistakes are punished heavily. |
| **RMSE** | Square root of MSE – in the same units as the target (e.g. lakhs). |
| **MAE** | Average absolute error. Easy to read. |
| **R² Score** | How much of the variation the model explains. 1.0 = perfect, 0 = no better than guessing the average. |

## 13. How the Code Works (File by File)

| File | Main contents |
|---|---|
| `preprocessing.py` | `load_data()`, `detect_problem_type()`, the `Preprocessor` class (clean + encode + remembers the columns so new inputs can be prepared the same way), `split_data()`, `scale_data()` |
| `models.py` | `get_model_names()`, `create_model()`, `train_models()` |
| `evaluation.py` | `evaluate_classification()`, `evaluate_regression()`, `evaluate_models()`, `get_best_model()` |
| `visualization.py` | One function per chart; each returns a Matplotlib figure |
| `app.py` | The Streamlit page. `run_training()` connects all steps. Results are stored in `st.session_state` so they survive page reruns. |

**Data flow**
```
CSV file → load_data → Preprocessor → split_data → scale_data
        → train_models → evaluate_models → charts + prediction form
```

## 14. Project Demonstration Guide

A simple 5–7 minute demo you can follow in a presentation or viva:

1. **Introduce the problem** (30 s) – "The app trains several ML models on a dataset and compares them."
2. **Start the app** – `streamlit run app.py`.
3. **Classification demo** (2 min)
   - Sidebar → *Sample dataset* → **Student Performance**. Target: `result`.
   - Open the **Dataset** tab: point out the 51 missing values and the text columns.
   - Click **Train Models**. In **Results**: show the best model, metrics table, comparison chart, ROC curves and confusion matrices.
   - Explain one confusion matrix (e.g. "37 passes were correctly found, 10 failures were wrongly predicted as pass").
4. **Make a prediction** (1 min) – Predict tab → use the example input from Section 9 → show *Pass* with its probability bars. Then change study hours to 1 and attendance to 55 → *Fail*.
5. **Regression demo** (2 min) – switch to **House Prices**, train, show the Actual-vs-Predicted graph and R², then predict a price.
6. **Upload demo** (1 min) – upload your own CSV (e.g. the `diabetes.csv` from Section 7) to show it works on new data.
7. **Wrap up** – best model per dataset, and limitations (Section 17).

**Likely questions**
- *Why split into train and test?* To measure performance on unseen data and detect overfitting.
- *Why does Random Forest usually beat a single tree?* Averaging many different trees reduces errors.
- *Is high accuracy always good?* Not with imbalanced classes — check precision, recall and F1.
- *Why scale the data?* Linear/Logistic Regression work better when columns share a similar scale.

## 15. Uploading to GitHub

### One-time setup
1. Create a free account at <https://github.com>.
2. Install Git from <https://git-scm.com/downloads>, then tell it who you are:
   ```bash
   git config --global user.name "Your Name"
   git config --global user.email "you@example.com"
   ```

### Create the repository on GitHub
1. Click **+ → New repository**.
2. Name it `predictive-modeling-ml`.
3. Add a description, choose **Public**.
4. **Do not** tick "Add a README" (you already have one). Click **Create repository**.

### Push your project
Open a terminal **inside the project folder** and run:
```bash
git init
git add .
git commit -m "Initial commit: Predictive Modeling Using Machine Learning"
git branch -M main
git remote add origin https://github.com/<your-username>/predictive-modeling-ml.git
git push -u origin main
```
Replace `<your-username>` with your GitHub username. When asked to sign in, use your GitHub
login (GitHub may ask for a **personal access token** instead of a password:
*Settings → Developer settings → Personal access tokens*).

### Updating later
```bash
git add .
git commit -m "Describe what you changed"
git push
```

### No-Git alternative
On your repository page click **Add file → Upload files**, drag in the project files and folders, and press **Commit changes**.

> 💡 The `.gitignore` file already stops your `venv/` folder from being uploaded.

## 16. Troubleshooting

| Problem | Fix |
|---|---|
| `streamlit: command not found` | Activate your virtual environment, or run `python -m streamlit run app.py` |
| `ModuleNotFoundError: No module named ...` | Run `pip install -r requirements.txt` again (with the venv active) |
| "Could not train the models: …" | Read the message – usually the wrong target column or problem type |
| "The target column … contains text" | You chose *Regression* for a text target – switch to *Classification* |
| "…looks like a Regression problem" | You chose *Classification* for a continuous number – switch to *Regression* |
| Garbled characters after upload | Save the CSV as **UTF-8** (Excel: *Save As → CSV UTF-8*) |
| Port already in use | `streamlit run app.py --server.port 8502` |

## 17. Limitations and Future Improvements

**Limitations (good points to mention honestly in a viva)**
- Missing values are filled using the whole dataset *before* splitting; a stricter approach fits the imputer on training data only.
- Models use fixed, sensible settings (no hyper-parameter tuning).
- Evaluation uses a single train/test split (no cross-validation).
- Very high-cardinality text columns (50+ unique values) are dropped automatically.

**Ideas for improvement**
- Add cross-validation and hyper-parameter tuning (`GridSearchCV`).
- Add more models (SVM, KNN, Gradient Boosting, XGBoost).
- Let users download the trained model (`joblib`) and the results table.
- Handle date columns and text columns (TF-IDF).
- Deploy for free on **Streamlit Community Cloud** straight from your GitHub repository.

---

*Built with Python, Scikit-learn and Streamlit.*
