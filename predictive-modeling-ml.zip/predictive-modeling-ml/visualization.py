"""
visualization.py
================
All the charts of the project. Every function RETURNS a Matplotlib figure,
so the same code works in the Streamlit app and in the terminal demo.
"""

import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
import seaborn as sns
from sklearn.metrics import confusion_matrix

from preprocessing import CLASSIFICATION

# A clean, modern look for every chart
sns.set_theme(style="whitegrid", font_scale=0.95)
PALETTE = ["#4F46E5", "#06B6D4", "#F59E0B", "#10B981", "#EF4444", "#8B5CF6"]


# ----------------------------------------------------------------------
# Classification charts
# ----------------------------------------------------------------------
def plot_confusion_matrix(y_test, y_pred, class_names, model_name):
    """
    Confusion matrix: rows = actual class, columns = predicted class.
    Numbers on the diagonal are correct predictions.
    """
    matrix = confusion_matrix(y_test, y_pred, labels=list(range(len(class_names))))

    fig, ax = plt.subplots(figsize=(5, 4))
    sns.heatmap(
        matrix, annot=True, fmt="d", cmap="Blues", cbar=False,
        xticklabels=class_names, yticklabels=class_names, ax=ax,
    )
    ax.set_xlabel("Predicted")
    ax.set_ylabel("Actual")
    ax.set_title(f"Confusion Matrix\n{model_name}", fontsize=11)
    fig.tight_layout()
    return fig


def plot_roc_curves(roc_by_model, n_classes):
    """
    ROC curves of all models in ONE chart.
    A curve closer to the top-left corner is better. The dashed line is random guessing.
    """
    fig, ax = plt.subplots(figsize=(6, 4.5))
    for i, (name, roc) in enumerate(roc_by_model.items()):
        if roc is None:
            continue
        ax.plot(roc["fpr"], roc["tpr"], linewidth=2, color=PALETTE[i % len(PALETTE)],
                label=f"{name} (AUC = {roc['auc']:.3f})")
    ax.plot([0, 1], [0, 1], "k--", linewidth=1, label="Random guess")

    ax.set_xlabel("False Positive Rate")
    ax.set_ylabel("True Positive Rate")
    title = "ROC Curves" if n_classes == 2 else "ROC Curves (micro-average)"
    ax.set_title(title, fontsize=11)
    ax.legend(loc="lower right", fontsize=8)
    fig.tight_layout()
    return fig


def plot_classification_comparison(results_df):
    """Grouped bar chart comparing Accuracy, Precision, Recall and F1 of all models."""
    metric_cols = ["Accuracy", "Precision", "Recall", "F1 Score"]
    long_df = results_df[metric_cols].reset_index().melt(
        id_vars="Model", var_name="Metric", value_name="Score"
    )

    fig, ax = plt.subplots(figsize=(7, 4.5))
    sns.barplot(data=long_df, x="Model", y="Score", hue="Metric",
                order=list(results_df.index), palette=PALETTE[:4], ax=ax)
    for container in ax.containers:
        ax.bar_label(container, fmt="%.2f", fontsize=7, padding=2)

    ax.set_ylim(0, 1.25)                       # extra room at the top for the legend
    ax.set_xlabel("")
    ax.set_title("Model Performance Comparison", fontsize=11)
    ax.set_xticks(range(len(results_df)))
    ax.set_xticklabels([name.replace(" ", "\n") for name in results_df.index])
    ax.legend(loc="upper center", fontsize=8, ncol=4)
    fig.tight_layout()
    return fig


# ----------------------------------------------------------------------
# Regression charts
# ----------------------------------------------------------------------
def plot_actual_vs_predicted(y_test, y_pred, model_name, r2):
    """
    Scatter plot of real values vs predicted values.
    Points close to the red dashed line mean accurate predictions.
    """
    fig, ax = plt.subplots(figsize=(5, 4.5))
    ax.scatter(y_test, y_pred, alpha=0.65, color=PALETTE[0], edgecolor="white", linewidth=0.5)

    low = min(np.min(y_test), np.min(y_pred))
    high = max(np.max(y_test), np.max(y_pred))
    ax.plot([low, high], [low, high], "r--", linewidth=1.5, label="Perfect prediction")

    ax.set_xlabel("Actual values")
    ax.set_ylabel("Predicted values")
    ax.set_title(f"Actual vs Predicted\n{model_name}  (R² = {r2:.3f})", fontsize=11)
    ax.legend(loc="upper left", fontsize=8)
    fig.tight_layout()
    return fig


def plot_regression_comparison(results_df):
    """Two bar charts: R2 Score (higher is better) and MSE (lower is better)."""
    labels = [name.replace(" ", "\n") for name in results_df.index]
    colors = PALETTE[:len(results_df)]

    fig, (ax1, ax2) = plt.subplots(1, 2, figsize=(10, 4.5))

    bars = ax1.bar(labels, results_df["R2 Score"], color=colors)
    ax1.bar_label(bars, fmt="%.3f", fontsize=8, padding=2)
    ax1.set_title("R² Score (higher is better)", fontsize=11)
    ax1.set_ylim(min(0, results_df["R2 Score"].min() - 0.05), 1.1)

    bars = ax2.bar(labels, results_df["MSE"], color=colors)
    ax2.bar_label(bars, fmt="%.1f", fontsize=8, padding=2)
    ax2.set_title("Mean Squared Error (lower is better)", fontsize=11)
    ax2.set_ylim(0, results_df["MSE"].max() * 1.15)

    fig.suptitle("Model Performance Comparison", fontsize=12)
    fig.tight_layout()
    return fig


# ----------------------------------------------------------------------
# Charts for both problem types
# ----------------------------------------------------------------------
def plot_feature_importance(model, feature_names, model_name, top_n=10):
    """Horizontal bar chart of the columns the tree-based model relied on most."""
    importance = pd.Series(model.feature_importances_, index=feature_names)
    importance = importance.sort_values(ascending=False).head(top_n)[::-1]

    fig, ax = plt.subplots(figsize=(5, 4))
    ax.barh(importance.index, importance.values, color=PALETTE[1])
    ax.set_xlabel("Importance")
    ax.set_title(f"Top Features\n{model_name}", fontsize=11)
    fig.tight_layout()
    return fig


def plot_target_distribution(target_column, problem_type):
    """Shows how the values of the target column are spread out."""
    fig, ax = plt.subplots(figsize=(5, 3.8))
    if problem_type == CLASSIFICATION:
        order = target_column.value_counts().index
        sns.countplot(x=target_column.astype(str), order=order.astype(str),
                      color=PALETTE[0], ax=ax)
        ax.set_ylabel("Count")
    else:
        sns.histplot(target_column.dropna(), kde=True, color=PALETTE[0], ax=ax)
        ax.set_ylabel("Frequency")
    ax.set_xlabel(str(target_column.name))
    ax.set_title("Target Distribution", fontsize=11)
    fig.tight_layout()
    return fig


def plot_correlation_heatmap(df):
    """Heatmap showing how strongly the numeric columns are related to each other."""
    numeric_df = df.select_dtypes(include="number")
    if numeric_df.shape[1] < 2:
        return None

    fig, ax = plt.subplots(figsize=(5.5, 4.5))
    show_numbers = numeric_df.shape[1] <= 10      # too many numbers become unreadable
    sns.heatmap(numeric_df.corr(), annot=show_numbers, fmt=".2f", cmap="coolwarm",
                center=0, ax=ax, annot_kws={"size": 7})
    ax.set_title("Correlation Heatmap", fontsize=11)
    fig.tight_layout()
    return fig
