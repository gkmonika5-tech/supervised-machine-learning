"""
generate_sample_data.py
=======================
Creates the three sample datasets in the sample_data/ folder.

    student_performance.csv - Classification (Pass / Fail)   - made-up data
    house_prices.csv        - Regression (price in lakhs)    - made-up data
    iris.csv                - Multi-class classification     - real data bundled with scikit-learn

Run it with:   python generate_sample_data.py
The made-up datasets deliberately contain a few MISSING values, so you can
see the preprocessing step handle them.
"""

from pathlib import Path

import numpy as np
import pandas as pd
from sklearn.datasets import load_iris

OUTPUT_DIR = Path(__file__).parent / "sample_data"
OUTPUT_DIR.mkdir(exist_ok=True)
rng = np.random.RandomState(42)          # fixed seed -> same data every time


def add_missing_values(df, columns, fraction=0.04):
    """Randomly blank out a small fraction of the values in the given columns."""
    for col in columns:
        mask = rng.rand(len(df)) < fraction
        df.loc[mask, col] = np.nan
    return df


# ----------------------------------------------------------------------
# 1. Student performance (classification)
# ----------------------------------------------------------------------
n = 300
study_hours = rng.uniform(0.5, 8, n).round(1)
attendance = rng.normal(75, 12, n).clip(40, 100).round(1)
previous_score = rng.normal(60, 15, n).clip(20, 100).round(0)
sleep_hours = rng.normal(7, 1.2, n).clip(4, 10).round(1)
internet = rng.choice(["Yes", "No"], n, p=[0.85, 0.15])
extra_classes = rng.choice(["Yes", "No"], n, p=[0.4, 0.6])
parent_edu = rng.choice(["High School", "Graduate", "Postgraduate"], n, p=[0.4, 0.4, 0.2])

edu_points = pd.Series(parent_edu).map({"High School": 0, "Graduate": 0.3, "Postgraduate": 0.6}).values
score = (0.45 * study_hours + 0.05 * (attendance - 75) + 0.06 * (previous_score - 60)
         + 0.2 * (sleep_hours - 7) + 0.6 * (extra_classes == "Yes") + edu_points - 1.4)
pass_probability = 1 / (1 + np.exp(-score))
result = np.where(rng.rand(n) < pass_probability, "Pass", "Fail")

students = pd.DataFrame({
    "study_hours_per_day": study_hours,
    "attendance_percent": attendance,
    "previous_exam_score": previous_score,
    "sleep_hours": sleep_hours,
    "internet_access": internet,
    "extra_classes": extra_classes,
    "parent_education": parent_edu,
    "result": result,
})
students = add_missing_values(students, ["study_hours_per_day", "attendance_percent",
                                         "sleep_hours", "parent_education"])
students.to_csv(OUTPUT_DIR / "student_performance.csv", index=False)
print("student_performance.csv ->", students.shape, dict(students["result"].value_counts()))

# ----------------------------------------------------------------------
# 2. House prices (regression)
# ----------------------------------------------------------------------
n = 400
area = rng.randint(500, 3500, n)
bedrooms = np.clip((area / 800 + rng.randint(-1, 2, n)).round(), 1, 5).astype(int)
bathrooms = np.clip((bedrooms - rng.randint(0, 2, n)), 1, 4).astype(int)
age = rng.randint(0, 40, n)
location = rng.choice(["Urban", "Suburban", "Rural"], n, p=[0.4, 0.35, 0.25])
parking = rng.choice(["Yes", "No"], n, p=[0.6, 0.4])

location_effect = pd.Series(location).map({"Urban": 30, "Suburban": 10, "Rural": -10}).values
price = (0.045 * area + 4 * bedrooms + 3 * bathrooms - 0.6 * age + location_effect
         + 6 * (parking == "Yes") + rng.normal(0, 12, n))
price = price.clip(min=15).round(2)

houses = pd.DataFrame({
    "area_sqft": area,
    "bedrooms": bedrooms,
    "bathrooms": bathrooms,
    "age_years": age,
    "location": location,
    "parking": parking,
    "price_lakhs": price,
})
houses = add_missing_values(houses, ["area_sqft", "age_years", "location"], fraction=0.03)
houses.to_csv(OUTPUT_DIR / "house_prices.csv", index=False)
print("house_prices.csv ->", houses.shape)

# ----------------------------------------------------------------------
# 3. Iris flowers (real dataset that ships with scikit-learn)
# ----------------------------------------------------------------------
iris = load_iris(as_frame=True)
iris_df = iris.frame.copy()
iris_df.columns = ["sepal_length_cm", "sepal_width_cm", "petal_length_cm", "petal_width_cm", "species"]
iris_df["species"] = iris_df["species"].map(dict(enumerate(iris.target_names)))
iris_df.to_csv(OUTPUT_DIR / "iris.csv", index=False)
print("iris.csv ->", iris_df.shape)
