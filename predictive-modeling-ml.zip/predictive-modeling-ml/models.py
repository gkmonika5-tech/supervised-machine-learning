"""
models.py
=========
Creates and trains the six machine learning models used in this project.

    Regression      -> predict a NUMBER   (e.g. a house price)
    Classification  -> predict a CATEGORY (e.g. Pass or Fail)
"""

from sklearn.ensemble import RandomForestClassifier, RandomForestRegressor
from sklearn.linear_model import LinearRegression, LogisticRegression
from sklearn.tree import DecisionTreeClassifier, DecisionTreeRegressor

from preprocessing import CLASSIFICATION

REGRESSION_MODELS = [
    "Linear Regression",
    "Decision Tree Regressor",
    "Random Forest Regressor",
]

CLASSIFICATION_MODELS = [
    "Logistic Regression",
    "Decision Tree Classifier",
    "Random Forest Classifier",
]

# Models that are made of decision trees (they can tell us which columns matter most)
TREE_MODELS = [
    "Decision Tree Regressor", "Random Forest Regressor",
    "Decision Tree Classifier", "Random Forest Classifier",
]


def get_model_names(problem_type):
    """Return the list of algorithms available for the chosen problem type."""
    if problem_type == CLASSIFICATION:
        return CLASSIFICATION_MODELS
    return REGRESSION_MODELS


def create_model(name):
    """
    Return a NEW, untrained model for the given name.

    random_state=42 makes the results repeatable (same answer every run).
    max_depth=5 on the single Decision Tree stops it from memorising the data.
    """
    if name == "Linear Regression":
        return LinearRegression()
    if name == "Decision Tree Regressor":
        return DecisionTreeRegressor(max_depth=5, random_state=42)
    if name == "Random Forest Regressor":
        return RandomForestRegressor(n_estimators=100, random_state=42)
    if name == "Logistic Regression":
        return LogisticRegression(max_iter=1000)
    if name == "Decision Tree Classifier":
        return DecisionTreeClassifier(max_depth=5, random_state=42)
    if name == "Random Forest Classifier":
        return RandomForestClassifier(n_estimators=100, random_state=42)
    raise ValueError(f"Unknown model name: {name}")


def train_models(selected_names, X_train, y_train):
    """
    Train every selected model on the training data.
    Returns a dictionary: {"model name": trained model}
    """
    trained = {}
    for name in selected_names:
        model = create_model(name)
        model.fit(X_train, y_train)      # <- this is where the model "learns"
        trained[name] = model
    return trained
