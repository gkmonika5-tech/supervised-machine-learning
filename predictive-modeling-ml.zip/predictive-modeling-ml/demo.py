"""
demo.py
=======
A terminal version of the project - NO Streamlit needed.

It runs the whole pipeline (preprocess -> train -> test -> evaluate -> charts)
on the sample datasets, prints the results and saves the charts into the
"screenshots" folder.

Run it with:   python demo.py
"""

from pathlib import Path

import matplotlib
matplotlib.use("Agg")          # draw charts into files instead of opening windows
import matplotlib.pyplot as plt
import pandas as pd

import visualization as viz
from evaluation import evaluate_models, get_best_model
from models import get_model_names, train_models
from preprocessing import (
    CLASSIFICATION, REGRESSION, Preprocessor, load_data, scale_data, scale_input, split_data,
)

BASE_DIR = Path(__file__).parent
OUTPUT_DIR = BASE_DIR / "screenshots"
OUTPUT_DIR.mkdir(exist_ok=True)
pd.set_option("display.width", 120)


def run_demo(csv_name, target, problem_type, sample_input, chart_prefix):
    print("\n" + "=" * 70)
    print(f"DATASET: {csv_name}   |   TARGET: {target}   |   {problem_type}")
    print("=" * 70)

    # 1. Load + preprocess
    df = load_data(BASE_DIR / "sample_data" / csv_name)
    print(f"Loaded {df.shape[0]} rows and {df.shape[1]} columns "
          f"({int(df.isnull().sum().sum())} missing values)")

    prep = Preprocessor(target, problem_type)
    X, y = prep.fit_transform(df)
    for line in prep.report:
        print("  -", line)

    # 2. Split, scale, train
    X_train, X_test, y_train, y_test = split_data(X, y, problem_type, test_size=0.2)
    X_train_s, X_test_s, scaler = scale_data(X_train, X_test)
    print(f"Training rows: {len(X_train)}   Testing rows: {len(X_test)}")

    models = train_models(get_model_names(problem_type), X_train_s, y_train)

    # 3. Evaluate
    n_classes = len(prep.class_names) if problem_type == CLASSIFICATION else None
    results, details = evaluate_models(models, X_test_s, y_test, problem_type, n_classes)
    print("\nModel performance:")
    print(results.round(4))

    best_name, metric, score = get_best_model(results, problem_type)
    print(f"\nBest model: {best_name} ({metric} = {score:.3f})")

    # 4. Charts
    if problem_type == CLASSIFICATION:
        figures = {
            "model_comparison": viz.plot_classification_comparison(results),
            "roc_curves": viz.plot_roc_curves({n: details[n]["roc"] for n in models}, n_classes),
            "confusion_matrix": viz.plot_confusion_matrix(
                y_test, details[best_name]["y_pred"], prep.class_names, best_name),
        }
    else:
        figures = {
            "model_comparison": viz.plot_regression_comparison(results),
            "actual_vs_predicted": viz.plot_actual_vs_predicted(
                y_test, details[best_name]["y_pred"], best_name, results.loc[best_name, "R2 Score"]),
        }
        # Tree-based models can also show which columns mattered most
        if hasattr(models[best_name], "feature_importances_"):
            figures["feature_importance"] = viz.plot_feature_importance(
                models[best_name], list(X.columns), best_name)
    for chart_name, fig in figures.items():
        path = OUTPUT_DIR / f"{chart_prefix}_{chart_name}.png"
        fig.savefig(path, dpi=130)
        plt.close(fig)
        print("Saved chart:", path.relative_to(BASE_DIR))

    # 5. Make a prediction for one new input
    row = scale_input(scaler, prep.transform_input(sample_input))
    print("\nSample input:", sample_input)
    for name, model in models.items():
        value = model.predict(row)[0]
        shown = prep.class_names[int(value)] if problem_type == CLASSIFICATION else f"{value:,.2f}"
        print(f"  {name:<26} -> {shown}")


if __name__ == "__main__":
    run_demo(
        "student_performance.csv", "result", CLASSIFICATION,
        {"study_hours_per_day": 6.0, "attendance_percent": 85.0, "previous_exam_score": 70,
         "sleep_hours": 7.5, "internet_access": "Yes", "extra_classes": "Yes",
         "parent_education": "Graduate"},
        chart_prefix="classification",
    )
    run_demo(
        "house_prices.csv", "price_lakhs", REGRESSION,
        {"area_sqft": 1800, "bedrooms": 3, "bathrooms": 2, "age_years": 5,
         "location": "Urban", "parking": "Yes"},
        chart_prefix="regression",
    )
    run_demo(
        "iris.csv", "species", CLASSIFICATION,
        {"sepal_length_cm": 5.9, "sepal_width_cm": 3.0, "petal_length_cm": 5.1, "petal_width_cm": 1.8},
        chart_prefix="multiclass_iris",
    )
