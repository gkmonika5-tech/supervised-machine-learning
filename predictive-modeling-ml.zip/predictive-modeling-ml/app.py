"""
app.py
======
The Streamlit dashboard - this is the file you RUN:

    streamlit run app.py

It connects the other files together:
    preprocessing.py -> prepares the data
    models.py        -> creates and trains the algorithms
    evaluation.py    -> measures the performance
    visualization.py -> draws the charts
"""

from pathlib import Path

import matplotlib.pyplot as plt
import pandas as pd
import streamlit as st

import visualization as viz
from evaluation import (
    evaluate_models, get_best_model, get_classification_report,
)
from models import TREE_MODELS, get_model_names, train_models
from preprocessing import (
    CLASSIFICATION, REGRESSION, Preprocessor, column_overview, detect_problem_type,
    get_dataset_summary, load_data, scale_data, scale_input, split_data,
)

# ----------------------------------------------------------------------
# Page settings and styling
# ----------------------------------------------------------------------
st.set_page_config(page_title="Predictive Modeling Using ML", page_icon="📈", layout="wide")

st.markdown(
    """
    <style>
    .banner {
        background: linear-gradient(120deg, #4F46E5 0%, #06B6D4 100%);
        padding: 28px 32px; border-radius: 16px; margin-bottom: 18px;
    }
    .banner h1 { color: white; margin: 0; font-size: 2.1rem; }
    .banner p  { color: rgba(255,255,255,0.92); margin: 6px 0 0 0; font-size: 1.02rem; }
    div[data-testid="stMetric"] {
        background-color: rgba(120, 120, 160, 0.10);
        border: 1px solid rgba(120, 120, 160, 0.25);
        padding: 12px 16px; border-radius: 12px;
    }
    </style>
    <div class="banner">
        <h1>📈 Predictive Modeling Using Machine Learning</h1>
        <p>Upload a dataset, train several algorithms, compare their accuracy and make your own predictions.</p>
    </div>
    """,
    unsafe_allow_html=True,
)

# Sample datasets: name -> (file name, default target column)
SAMPLE_DIR = Path(__file__).parent / "sample_data"
SAMPLES = {
    "Student Performance (Classification)": ("student_performance.csv", "result"),
    "House Prices (Regression)": ("house_prices.csv", "price_lakhs"),
    "Iris Flowers (Multi-class Classification)": ("iris.csv", "species"),
}


# ----------------------------------------------------------------------
# Helper functions
# ----------------------------------------------------------------------
def show_figure(fig):
    """Display a Matplotlib figure in Streamlit and free its memory."""
    st.pyplot(fig)
    plt.close(fig)


def show_welcome():
    """Message shown before any dataset is loaded."""
    st.info("👈 Upload a CSV file in the sidebar to begin, or switch to a **sample dataset**.")
    st.markdown(
        """
        ### How this app works
        1. **Load** a dataset (your own CSV or a sample).
        2. **Pick the target column** - the thing you want to predict.
        3. **Choose algorithms** and click **Train Models**.
        4. **Compare** accuracy, confusion matrices, ROC curves and prediction graphs.
        5. **Predict** - type in new values and get a prediction.
        """
    )


def run_training(df, target, problem_type, ignore_cols, selected_models, test_size):
    """
    The complete machine learning pipeline:
    clean data -> split -> scale -> train -> evaluate.
    Returns a dictionary with everything the dashboard needs to show.
    """
    # 1. Preprocess
    prep = Preprocessor(target, problem_type, ignore_cols)
    X, y = prep.fit_transform(df)

    # 2. Split into training and testing data
    X_train, X_test, y_train, y_test = split_data(X, y, problem_type, test_size)

    # 3. Scale the numbers
    X_train_scaled, X_test_scaled, scaler = scale_data(X_train, X_test)

    # 4. Train the selected models
    trained_models = train_models(selected_models, X_train_scaled, y_train)

    # 5. Test the models
    n_classes = len(prep.class_names) if problem_type == CLASSIFICATION else None
    results, details = evaluate_models(trained_models, X_test_scaled, y_test, problem_type, n_classes)

    return {
        "preprocessor": prep,
        "scaler": scaler,
        "models": trained_models,
        "results": results,
        "details": details,
        "y_test": y_test,
        "feature_names": list(X.columns),
        "n_train": len(X_train),
        "n_test": len(X_test),
        "problem_type": problem_type,
        "target": target,
    }


# ----------------------------------------------------------------------
# Sidebar: dataset + settings + train button
# ----------------------------------------------------------------------
df = None
with st.sidebar:
    st.header("⚙️ Control Panel")

    # ---- 1. Dataset upload section
    st.subheader("1. Dataset")
    source = st.radio("Data source", ["Sample dataset", "Upload my own CSV"])

    dataset_name = ""
    default_target = None
    if source == "Sample dataset":
        sample_choice = st.selectbox("Choose a sample", list(SAMPLES.keys()))
        file_name, default_target = SAMPLES[sample_choice]
        df = load_data(SAMPLE_DIR / file_name)
        dataset_name = file_name
    else:
        uploaded_file = st.file_uploader("Upload a CSV file", type=["csv"])
        if uploaded_file is not None:
            try:
                df = load_data(uploaded_file)
                dataset_name = uploaded_file.name
            except Exception as error:
                st.error(f"Could not read this file: {error}")

    # ---- 2. Target and settings (only shown once a dataset is loaded)
    if df is not None:
        st.subheader("2. Target & Settings")

        columns = list(df.columns)
        default_index = columns.index(default_target) if default_target in columns else len(columns) - 1
        target = st.selectbox("Target column (what to predict)", columns, index=default_index)

        other_columns = [c for c in columns if c != target]
        ignore_cols = st.multiselect("Columns to ignore (e.g. ID columns)", other_columns)

        detected_type = detect_problem_type(df[target])
        type_choice = st.radio("Problem type", ["Auto-detect", CLASSIFICATION, REGRESSION])
        problem_type = detected_type if type_choice == "Auto-detect" else type_choice
        st.caption(f"Detected: **{detected_type}**  |  Using: **{problem_type}**")

        test_percent = st.slider("Test data size (%)", min_value=10, max_value=40, value=20, step=5)

        # ---- 3. Algorithm selection
        st.subheader("3. Algorithms")
        available_models = get_model_names(problem_type)
        selected_models = st.multiselect(
            "Select algorithms to train", available_models, default=available_models,
            key=f"algorithms_{problem_type}",
        )

        # ---- 4. Train button
        train_clicked = st.button("🚀 Train Models", type="primary")

# Nothing more to show until a dataset is loaded
if df is None:
    show_welcome()
    st.stop()

# This key describes the current data settings. If the user changes them
# after training, the old results no longer match and are hidden.
current_key = (dataset_name, target, problem_type, tuple(ignore_cols))

# ----------------------------------------------------------------------
# Train when the button is clicked
# ----------------------------------------------------------------------
if train_clicked:
    if len(selected_models) == 0:
        st.warning("Please select at least one algorithm in the sidebar.")
    else:
        try:
            with st.spinner("Preprocessing data and training models..."):
                trained = run_training(df, target, problem_type, ignore_cols,
                                       selected_models, test_percent / 100)
                trained["key"] = current_key
                st.session_state["trained"] = trained    # keep results between reruns
            st.success("Training complete! Open the **Results** and **Predict** tabs.")
        except ValueError as error:
            st.error(f"Could not train the models: {error}")


# ----------------------------------------------------------------------
# The three main tabs
# ----------------------------------------------------------------------
tab_data, tab_results, tab_predict = st.tabs(["📊 Dataset", "🏆 Results", "🔮 Predict"])

# ======================= TAB 1: DATASET =======================
with tab_data:
    st.subheader(f"Dataset preview - {dataset_name}")

    summary = get_dataset_summary(df)
    c1, c2, c3, c4 = st.columns(4)
    c1.metric("Rows", f"{summary['rows']:,}")
    c2.metric("Columns", summary["columns"])
    c3.metric("Missing values", summary["missing"])
    c4.metric("Duplicate rows", summary["duplicates"])

    st.dataframe(df.head(20))

    with st.expander("Column details (data types, missing values)"):
        st.dataframe(column_overview(df))

    numeric_part = df.select_dtypes(include="number")
    if not numeric_part.empty:
        with st.expander("Summary statistics of numeric columns"):
            st.dataframe(numeric_part.describe().round(2))

    st.subheader("Explore the data")
    left, right = st.columns(2)
    with left:
        show_figure(viz.plot_target_distribution(df[target], problem_type))
    with right:
        heatmap = viz.plot_correlation_heatmap(df)
        if heatmap is not None:
            show_figure(heatmap)
        else:
            st.info("The correlation heatmap needs at least two numeric columns.")


# ======================= TAB 2: RESULTS =======================
def show_results(trained):
    """Show metrics, comparison charts, confusion matrices, ROC curves, etc."""
    results = trained["results"]
    details = trained["details"]
    models = trained["models"]
    y_test = trained["y_test"]
    prep = trained["preprocessor"]
    is_classification = trained["problem_type"] == CLASSIFICATION

    st.caption(
        f"Target: **{trained['target']}**  |  Problem: **{trained['problem_type']}**  |  "
        f"Training rows: **{trained['n_train']}**  |  Testing rows: **{trained['n_test']}**"
    )

    # ---- Best model summary
    best_name, best_metric, best_score = get_best_model(results, trained["problem_type"])
    m1, m2, m3 = st.columns(3)
    m1.metric("🥇 Best model", best_name)
    m2.metric(f"Best {best_metric}", f"{best_score:.3f}")
    m3.metric("Models trained", len(models))

    with st.expander("What happened during preprocessing?"):
        for line in prep.report:
            st.write("• " + line)

    # ---- Metrics table
    st.subheader("Model performance")
    st.dataframe(results.round(4))
    if is_classification:
        st.caption("Accuracy = share of correct predictions. Precision, Recall and F1 are explained in the README.")
    else:
        st.caption("MSE and RMSE: lower is better. R² Score: closer to 1 is better.")

    # ---- Comparison charts
    st.subheader("Model comparison")
    if is_classification:
        col_a, col_b = st.columns(2)
        with col_a:
            show_figure(viz.plot_classification_comparison(results))
        with col_b:
            roc_data = {name: details[name]["roc"] for name in models}
            show_figure(viz.plot_roc_curves(roc_data, len(prep.class_names)))
    else:
        show_figure(viz.plot_regression_comparison(results))

    # ---- Per-model charts
    names = list(models.keys())
    if is_classification:
        st.subheader("Confusion matrices")
        columns = st.columns(len(names))
        for column, name in zip(columns, names):
            with column:
                show_figure(viz.plot_confusion_matrix(
                    y_test, details[name]["y_pred"], prep.class_names, name))

        with st.expander("Detailed classification report (precision / recall / F1 per class)"):
            chosen = st.selectbox("Model", names)
            st.code(get_classification_report(y_test, details[chosen]["y_pred"], prep.class_names))
    else:
        st.subheader("Actual vs Predicted")
        columns = st.columns(len(names))
        for column, name in zip(columns, names):
            with column:
                show_figure(viz.plot_actual_vs_predicted(
                    y_test, details[name]["y_pred"], name, results.loc[name, "R2 Score"]))

    # ---- Feature importance (only for tree-based models)
    tree_names = [name for name in names if name in TREE_MODELS]
    if tree_names:
        with st.expander("Which columns matter most? (tree-based models)"):
            columns = st.columns(len(tree_names))
            for column, name in zip(columns, tree_names):
                with column:
                    show_figure(viz.plot_feature_importance(models[name], trained["feature_names"], name))


with tab_results:
    saved = st.session_state.get("trained")
    if saved is None or saved["key"] != current_key:
        st.info("👈 Select your algorithms in the sidebar and click **Train Models** to see the results.")
    else:
        show_results(saved)


# ======================= TAB 3: PREDICT =======================
def show_prediction(trained):
    """A form where the user types values and gets a prediction."""
    prep = trained["preprocessor"]
    models = trained["models"]
    is_classification = trained["problem_type"] == CLASSIFICATION

    st.subheader(f"Predict: {trained['target']}")
    model_name = st.selectbox("Choose a trained model", list(models.keys()))

    # Using a form means the page only updates when "Predict" is pressed
    with st.form("prediction_form"):
        st.write("Enter the values for each column:")
        user_values = {}
        form_columns = st.columns(3)

        for i, col_name in enumerate(prep.feature_cols):
            info = prep.feature_info[col_name]
            with form_columns[i % 3]:
                if info["type"] == "numeric":
                    hint = f"Values in the training data: {info['min']:g} to {info['max']:g}"
                    if info["is_integer"]:
                        user_values[col_name] = st.number_input(
                            col_name, value=int(info["median"]), step=1, help=hint)
                    else:
                        user_values[col_name] = st.number_input(
                            col_name, value=float(info["median"]), step=float(info["step"]),
                            format="%g", help=hint)
                else:
                    user_values[col_name] = st.selectbox(col_name, info["options"])

        submitted = st.form_submit_button("🔮 Predict")

    if submitted:
        # Prepare the input exactly like the training data, then predict
        row = scale_input(trained["scaler"], prep.transform_input(user_values))
        model = models[model_name]
        prediction = model.predict(row)[0]

        if is_classification:
            label = prep.class_names[int(prediction)]
            st.success(f"Predicted **{trained['target']}**: **{label}**  (using {model_name})")

            probabilities = model.predict_proba(row)[0]
            class_labels = [prep.class_names[int(c)] for c in model.classes_]
            prob_table = pd.DataFrame({"Probability": probabilities}, index=class_labels)
            st.write("Confidence for each class:")
            st.bar_chart(prob_table)
        else:
            st.metric(f"Predicted {trained['target']} (using {model_name})", f"{prediction:,.2f}")

        # What do all the trained models say?
        st.write("**What every trained model predicts for this input:**")
        rows = []
        for name, other_model in models.items():
            value = other_model.predict(row)[0]
            rows.append({"Model": name,
                         "Prediction": prep.class_names[int(value)] if is_classification else round(float(value), 2)})
        st.dataframe(pd.DataFrame(rows).set_index("Model"))


with tab_predict:
    saved = st.session_state.get("trained")
    if saved is None or saved["key"] != current_key:
        st.info("👈 Train the models first, then come back here to make predictions.")
    else:
        show_prediction(saved)

st.markdown("---")
st.caption("Predictive Modeling Using Machine Learning · Built with Python, Scikit-learn and Streamlit")
