"""
preprocessing.py
================
Everything related to PREPARING a dataset for machine learning:

    1. load_data()        - read a CSV file
    2. Preprocessor       - clean the data, fill missing values, encode text columns
    3. split_data()       - split into training data and testing data
    4. scale_data()       - put all numeric columns on a similar scale

Machine learning models only understand numbers, so this file turns a
"messy" CSV into a clean table of numbers.
"""

import numpy as np
import pandas as pd
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import LabelEncoder, StandardScaler

# Names used everywhere in the project (so we never mistype them)
CLASSIFICATION = "Classification"
REGRESSION = "Regression"

# Text columns with more unique values than this (like names or IDs) are not useful
MAX_CATEGORIES = 50


# ----------------------------------------------------------------------
# 1. Loading data
# ----------------------------------------------------------------------
def load_data(file):
    """Read a CSV file (a file path or an uploaded file) into a DataFrame."""
    try:
        df = pd.read_csv(file)
    except UnicodeDecodeError:
        # Some Excel-made CSV files use a different text encoding
        if hasattr(file, "seek"):
            file.seek(0)
        df = pd.read_csv(file, encoding="latin-1")

    # Remove accidental spaces around column names
    df.columns = [str(col).strip() for col in df.columns]
    return df


def get_dataset_summary(df):
    """Return a few quick facts about the dataset (used on the dashboard)."""
    return {
        "rows": df.shape[0],
        "columns": df.shape[1],
        "missing": int(df.isnull().sum().sum()),
        "duplicates": int(df.duplicated().sum()),
    }


def column_overview(df):
    """Return a table showing the data type, missing values and unique values of each column."""
    return pd.DataFrame({
        "Data Type": df.dtypes.astype(str),
        "Missing Values": df.isnull().sum(),
        "Unique Values": df.nunique(),
    })


def detect_problem_type(target_column):
    """
    Guess whether the target column needs Classification or Regression.

    - Text/boolean columns                  -> Classification (e.g. Pass / Fail)
    - Whole numbers with 10 or fewer values -> Classification (e.g. 0 / 1)
    - Everything else                       -> Regression     (e.g. a house price)
    """
    if pd.api.types.is_bool_dtype(target_column):
        return CLASSIFICATION
    if not pd.api.types.is_numeric_dtype(target_column):
        return CLASSIFICATION

    values = target_column.dropna()
    all_whole_numbers = bool((values == values.round()).all())
    if values.nunique() <= 10 and all_whole_numbers:
        return CLASSIFICATION
    return REGRESSION


# ----------------------------------------------------------------------
# 2. Cleaning + encoding
# ----------------------------------------------------------------------
class Preprocessor:
    """
    Prepares a dataset for machine learning.

    Usage:
        prep = Preprocessor(target="price", problem_type="Regression")
        X, y = prep.fit_transform(df)          # cleaned numeric data
        row  = prep.transform_input({...})     # prepare ONE new row for a prediction

    After fit_transform() the object remembers everything it learned
    (column names, categories, ...) so new inputs can be prepared in exactly
    the same way.
    """

    def __init__(self, target, problem_type, ignore_columns=None):
        self.target = target
        self.problem_type = problem_type
        self.ignore_columns = ignore_columns or []

        # These are filled in by fit_transform()
        self.feature_cols = []        # original input columns that are used
        self.numeric_cols = []
        self.categorical_cols = []
        self.feature_info = {}        # min / max / options for each input column
        self.encoded_columns = []     # column names after one-hot encoding
        self.class_names = []         # for classification: the original label names
        self.report = []              # human-readable list of what we did

    def fit_transform(self, df):
        """Clean the dataset and return (X, y) - both fully numeric."""
        df = df.copy()

        # --- Step 1: remove columns the user wants to ignore (like an ID column)
        if self.ignore_columns:
            df = df.drop(columns=self.ignore_columns)
            self.report.append("Ignored columns: " + ", ".join(self.ignore_columns))

        # --- Step 2: rows without a target value cannot be used for training
        rows_before = len(df)
        df = df.dropna(subset=[self.target])
        if len(df) < rows_before:
            self.report.append(f"Removed {rows_before - len(df)} rows with a missing target value.")

        # --- Step 3: remove duplicate rows
        rows_before = len(df)
        df = df.drop_duplicates()
        if len(df) < rows_before:
            self.report.append(f"Removed {rows_before - len(df)} duplicate rows.")
        df = df.reset_index(drop=True)

        if len(df) < 20:
            raise ValueError("The dataset needs at least 20 usable rows to train and test a model.")

        # --- Step 4: separate the inputs (X) from the target (y)
        y_raw = df[self.target]
        X = df.drop(columns=[self.target])

        if self.problem_type == REGRESSION and not pd.api.types.is_numeric_dtype(y_raw):
            raise ValueError(
                f"The target column '{self.target}' contains text, so it cannot be used for "
                "Regression. Choose 'Classification' instead."
            )

        # --- Step 5: True/False columns become 1/0
        for col in X.columns:
            if pd.api.types.is_bool_dtype(X[col]):
                X[col] = X[col].astype(int)

        # --- Step 6: drop columns that are empty or useless (e.g. names, IDs)
        for col in list(X.columns):
            if X[col].isnull().all():
                X = X.drop(columns=col)
                self.report.append(f"Dropped '{col}' because it is completely empty.")
            elif not pd.api.types.is_numeric_dtype(X[col]) and X[col].nunique() > MAX_CATEGORIES:
                X = X.drop(columns=col)
                self.report.append(
                    f"Dropped '{col}' because it has too many different text values."
                )

        if X.shape[1] == 0:
            raise ValueError("No usable input columns are left. Check your target and ignored columns.")

        # --- Step 7: fill missing values
        #     numbers -> median (middle value)    text -> most common value
        self.numeric_cols = [c for c in X.columns if pd.api.types.is_numeric_dtype(X[c])]
        self.categorical_cols = [c for c in X.columns if c not in self.numeric_cols]

        filled = 0
        for col in self.numeric_cols:
            missing = int(X[col].isnull().sum())
            if missing > 0:
                X[col] = X[col].fillna(X[col].median())
                filled += missing
        for col in self.categorical_cols:
            X[col] = X[col].astype("object")
            missing = int(X[col].isnull().sum())
            if missing > 0:
                X[col] = X[col].fillna(X[col].mode()[0])
                filled += missing
            X[col] = X[col].astype(str)
        if filled > 0:
            self.report.append(
                f"Filled {filled} missing values (median for numbers, most common value for text)."
            )

        # --- Step 8: remember each column's details (used by the Prediction form)
        self.feature_cols = list(X.columns)
        for col in self.numeric_cols:
            col_min, col_max = float(X[col].min()), float(X[col].max())
            self.feature_info[col] = {
                "type": "numeric",
                "min": col_min,
                "max": col_max,
                "median": float(X[col].median()),
                "is_integer": bool((X[col] == X[col].round()).all()),
                "step": round(max((col_max - col_min) / 100, 0.01), 4),
            }
        for col in self.categorical_cols:
            self.feature_info[col] = {"type": "categorical", "options": sorted(X[col].unique())}

        # --- Step 9: one-hot encoding
        #     A column "location" with values Urban / Rural becomes two columns:
        #     location_Urban (1 or 0) and location_Rural (1 or 0)
        if self.categorical_cols:
            report_cols = ", ".join(self.categorical_cols)
            self.report.append(f"One-hot encoded text columns: {report_cols}.")
        X = pd.get_dummies(X, columns=self.categorical_cols, dtype=float)
        X = X.astype(float)
        self.encoded_columns = list(X.columns)

        # --- Step 10: prepare the target
        if self.problem_type == CLASSIFICATION:
            encoder = LabelEncoder()           # turns labels (Pass/Fail) into 0/1/2...
            y = encoder.fit_transform(y_raw.to_numpy())
            # Show whole-number labels as 0, 1, 2 (not 0.0, 1.0, 2.0)
            self.class_names = [
                str(int(c)) if isinstance(c, (float, np.floating)) and float(c).is_integer() else str(c)
                for c in encoder.classes_
            ]
            if len(self.class_names) < 2:
                raise ValueError("The target column has only one class, so nothing can be predicted.")
            if len(self.class_names) > 20:
                raise ValueError(
                    f"The target column has {len(self.class_names)} different values. "
                    "That looks like a Regression problem."
                )
            self.report.append("Target classes: " + ", ".join(self.class_names) + ".")
        else:
            y = y_raw.astype(float).to_numpy()

        return X, y

    def transform_input(self, user_values):
        """
        Convert ONE row of user input (a dictionary like {"age": 20, "city": "Urban"})
        into the same numeric format the models were trained on.
        """
        row = pd.DataFrame([user_values])
        for col in self.categorical_cols:
            row[col] = row[col].astype(str)
        row = pd.get_dummies(row, columns=self.categorical_cols, dtype=float)
        # Make sure every training column exists (missing dummy columns become 0)
        row = row.reindex(columns=self.encoded_columns, fill_value=0.0)
        return row.astype(float)


# ----------------------------------------------------------------------
# 3. Train / test split
# ----------------------------------------------------------------------
def split_data(X, y, problem_type, test_size=0.2, random_state=42):
    """
    Split the data into a TRAINING set (the model learns from it) and a
    TESTING set (we check the model on data it has never seen).
    """
    stratify = None
    if problem_type == CLASSIFICATION and np.bincount(y).min() >= 2:
        stratify = y   # keeps the same class proportions in both sets

    try:
        return train_test_split(X, y, test_size=test_size, random_state=random_state, stratify=stratify)
    except ValueError:
        # Stratifying is not possible for very small classes - split normally
        return train_test_split(X, y, test_size=test_size, random_state=random_state)


# ----------------------------------------------------------------------
# 4. Feature scaling
# ----------------------------------------------------------------------
def scale_data(X_train, X_test):
    """
    Standardise the numbers (mean 0, standard deviation 1).
    The scaler learns ONLY from the training data, then is applied to both sets.
    """
    scaler = StandardScaler()
    X_train_scaled = pd.DataFrame(
        scaler.fit_transform(X_train), columns=X_train.columns, index=X_train.index
    )
    X_test_scaled = pd.DataFrame(
        scaler.transform(X_test), columns=X_test.columns, index=X_test.index
    )
    return X_train_scaled, X_test_scaled, scaler


def scale_input(scaler, row):
    """Apply an already-fitted scaler to a single prepared input row."""
    return pd.DataFrame(scaler.transform(row), columns=row.columns)
